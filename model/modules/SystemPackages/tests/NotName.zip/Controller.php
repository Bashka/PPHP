<?php
namespace PPHP\model\modules\SystemPackages\tests\TestA;

use PPHP\model\classes\ModuleController;


class Controller extends ModuleController{
}
